module.exports = require('constants')
