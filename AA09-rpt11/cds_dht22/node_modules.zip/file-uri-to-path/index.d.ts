declare function fileUriToPath(uri: string): string;
export = fileUriToPath;
